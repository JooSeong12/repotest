package com.example.schoolmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolmanagerApplication.class, args);
	}

}
