package com.example.golfApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="teacher")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeacherEntity {
    @Id
    private String teacher_code;
    private String teacher_name;
    private String class_name;
    private int class_price;
    private String teacher_gegist_date;
}
