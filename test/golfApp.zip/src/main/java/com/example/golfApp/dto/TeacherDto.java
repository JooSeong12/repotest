package com.example.golfApp.dto;

import com.example.golfApp.entity.TeacherEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TeacherDto {
    private String teacher_code;
    private String teacher_name;
    private String class_name;
    private int class_price;
    private String teacher_gegist_date;

    public static TeacherDto fromTeacherEntity(TeacherEntity teacherEntity){
        return new TeacherDto(teacherEntity.getTeacher_code(), teacherEntity.getTeacher_name(), teacherEntity.getClass_name(),
                teacherEntity.getClass_price(), teacherEntity.getTeacher_gegist_date());
    }

    public static TeacherEntity fromTeacherDto(TeacherDto teacherDto){
        TeacherEntity teacherEntity = new TeacherEntity();
        teacherEntity.setTeacher_code(teacherDto.getTeacher_code());
        teacherEntity.setTeacher_name(teacherDto.getTeacher_name());
        teacherEntity.setClass_name(teacherDto.getClass_name());
        teacherEntity.setClass_price(teacherDto.getClass_price());
        teacherEntity.setTeacher_gegist_date(teacherDto.getTeacher_gegist_date());
        return teacherEntity;
    }
}
