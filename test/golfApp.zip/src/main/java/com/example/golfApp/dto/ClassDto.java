package com.example.golfApp.dto;

import com.example.golfApp.entity.ClassEntity;
import com.example.golfApp.entity.TeacherEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ClassDto {
    private Long class_id;
    private String regist_month;
    private String class_no;
    private String class_area;
    private int tuition;
    private String teacher_code;

    public static ClassDto fromClassEntity(ClassEntity classEntity){
        return new ClassDto(classEntity.getClass_id(), classEntity.getRegist_month(), classEntity.getClass_no(),
                classEntity.getClass_area(), classEntity.getTuition(), classEntity.getTeacher_code());
    }

    public static ClassEntity fromClassDto(ClassDto classDto){
        ClassEntity classEntity = new ClassEntity();
        classEntity.setClass_id(classDto.getClass_id());
        classEntity.setRegist_month(classDto.getRegist_month());
        classEntity.setClass_no(classDto.getClass_no());
        classEntity.setClass_area(classDto.getClass_area());
        classEntity.setTuition(classDto.getTuition());
        classEntity.setTeacher_code(classDto.getTeacher_code());
        return classEntity;
    }
}
