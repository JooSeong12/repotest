package com.wemake.scrap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrapApplicationTests {

    @Test
    void contextLoads() {
    }

}
