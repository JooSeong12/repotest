package com.example.Peti.model;

import lombok.Data;

@Data
public class ReportForm {
    private String memo;
}
