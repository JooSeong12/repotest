package com.example.schoolmanager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HospitalDto {
    private String hostCode;
    private String hostName;
    private String hostTel;
    private String hostAddr;
}
