package com.example.Peti.service;

public interface PetiReportService {

    public String stringRlmnNo(String memo) throws Exception;
}
