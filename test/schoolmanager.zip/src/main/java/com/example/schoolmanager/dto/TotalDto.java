package com.example.schoolmanager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Getter
@Setter
@ToString
public class TotalDto {
    private Long resvNo;
    private String name;
    private String gender;
    private String hostName;
    @DateTimeFormat(pattern = "yyyyMMdd")
    private LocalDate resvDate;
    @DateTimeFormat(pattern = "HHmm")
    private LocalTime resvTime;
    private String vCode;
    private String hostAddr;
}
