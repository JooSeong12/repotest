package com.example.golfApp.controller;

import com.example.golfApp.dto.ClassDto;
import com.example.golfApp.dto.MemberDto;
import com.example.golfApp.dto.TeacherDto;
import com.example.golfApp.service.GolfService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class GolfController {
    private final GolfService golfService;

    public GolfController(GolfService golfService) {
        this.golfService = golfService;
    }

    @GetMapping("main")
    public String mainView(){
        return "/articles/main";
    }
    @GetMapping("viewTeacher")
    public String viewTeacher(Model model){
        List<TeacherDto> dtoList = golfService.viewTeacher();
        model.addAttribute("dto", dtoList);
        return "/articles/viewTeacher";
    }
    @GetMapping("applyClass")
    public String applyClass(Model model){
        List<TeacherDto> teacherDtoList = golfService.viewTeacher();
        System.out.println(teacherDtoList.toString());
        List<MemberDto> memberDtoList = golfService.viewMember();

        model.addAttribute("teacherList", teacherDtoList);
        model.addAttribute("memberList", memberDtoList);
        model.addAttribute("classDto", new ClassDto());
        return "/articles/applyClass";
    }
}
