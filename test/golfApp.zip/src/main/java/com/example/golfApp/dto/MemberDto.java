package com.example.golfApp.dto;

import com.example.golfApp.entity.MemberEntity;
import com.example.golfApp.entity.TeacherEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MemberDto {
    private String member_id;
    private String member_name;
    private String phone;
    private String address;
    private String grade;

    public static MemberDto fromMemeberEntity(MemberEntity member){
        return new MemberDto(member.getMember_id(), member.getMember_name(), member.getPhone(), member.getAddress(), member.getGrade());
    }

    public static MemberEntity fromMemberDto(MemberDto memberDto){
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setMember_id(memberDto.getMember_id());
        memberEntity.setMember_name(memberDto.getMember_name());
        memberEntity.setPhone(memberDto.getPhone());
        memberEntity.setAddress(memberDto.getAddress());
        memberEntity.setGrade(memberDto.getGrade());
        return memberEntity;
    }
}
