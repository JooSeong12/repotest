function memberNumber(){
    var memberName = document.getElementById("memberName").value;
    var memberId = document.getElementById("memberId");

    memberId.value = memberName
}

function classSelect(){
    var className = document.getElementById("className").value;
    var classPrice = document.getElementById("classPrice");

    classPrice.value = className
}