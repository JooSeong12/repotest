package com.example.Peti.service.impl;

import com.example.Peti.service.PetiReportService;
import org.springframework.stereotype.Service;

@Service("PetiReportService")
public class PetiReportServiceImpl implements PetiReportService {

    @Override
    public String stringRlmnNo(String memo) throws Exception {
        return "";
    }
}
