package com.example.Peti.web;

import com.example.Peti.model.ReportForm;
import com.example.Peti.service.PetiReportService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import java.util.List;

@Controller
public class PetiReportController {

    @Resource(name = "PetiReportService")
    private PetiReportService petiReportService;

    @GetMapping("/search.do")
    public ModelAndView customerSearch() throws Exception{
        return new ModelAndView("/html/PetiReport");
    }

}
