package com.example.schoolmanager.service;

import com.example.schoolmanager.dto.TotalDto;
import com.example.schoolmanager.dto.VaccresvDto;
import com.example.schoolmanager.mapper.ReservationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ReservationService {
    @Autowired
    ReservationMapper reservationMapper;

    public Long findResvNo(){
        return reservationMapper.findResvNo();
    }

    public void saveReservation(VaccresvDto vaccresvDto) {
        System.out.println(vaccresvDto.toString());
        reservationMapper.saveReservation(vaccresvDto);
    }

    public List<TotalDto> findTotal(Long resvNo) {
        return reservationMapper.findTotal(resvNo);
    }
}
