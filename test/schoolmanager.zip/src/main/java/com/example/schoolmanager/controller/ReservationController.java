package com.example.schoolmanager.controller;

import com.example.schoolmanager.dto.TotalDto;
import com.example.schoolmanager.dto.VaccresvDto;
import com.example.schoolmanager.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ReservationController {
    @Autowired
    ReservationService reservationService;
    @GetMapping("/")
    public String mainPage(){
        return "main";
    }

    @GetMapping("/reservation")
    public String reservation(Model model){
        Long resvNo = reservationService.findResvNo();
        VaccresvDto dto = new VaccresvDto();
        model.addAttribute("resv", resvNo);
        model.addAttribute("dto", dto);
        return "reservation";
    }

    @PostMapping("/reservation")
    public String reservationPost(VaccresvDto vaccresvDto){
        System.out.println(vaccresvDto.toString());
        reservationService.saveReservation(vaccresvDto);

        return "redirect:/";
    }

    @GetMapping("/search")
    public String search(Model model){
        VaccresvDto vaccresvDto = new VaccresvDto();
        model.addAttribute("resv", vaccresvDto);
        return "/search";
    }

    @GetMapping("/search/{resvNo}")
    public String searchNo(@RequestParam("resvNo")Long resvNo, Model model){
        List<TotalDto> totalDto = reservationService.findTotal(resvNo);
        System.out.println(totalDto.toString());
        model.addAttribute("list", totalDto);
        return "resvNo";
    }
}
