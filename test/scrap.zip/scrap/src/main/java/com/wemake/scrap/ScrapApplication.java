package com.wemake.scrap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrapApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScrapApplication.class, args);
    }

}
