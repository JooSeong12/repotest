package com.example.golfApp.service;

import com.example.golfApp.dto.ClassDto;
import com.example.golfApp.dto.MemberDto;
import com.example.golfApp.dto.TeacherDto;
import com.example.golfApp.entity.TeacherEntity;
import com.example.golfApp.repository.ClassRepository;
import com.example.golfApp.repository.MemberRepository;
import com.example.golfApp.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GolfService {
    private final TeacherRepository teacherRepository;
    private final ClassRepository classRepository;
    private final MemberRepository memberRepository;

    public GolfService(TeacherRepository teacherRepository, ClassRepository classRepository, MemberRepository memberRepository) {
        this.teacherRepository = teacherRepository;
        this.classRepository = classRepository;
        this.memberRepository = memberRepository;
    }

    public List viewTeacher(){
        List<TeacherDto> teacherDtoList = teacherRepository.findAll().stream().map(x-> TeacherDto.fromTeacherEntity(x)).toList();
        return teacherDtoList;
    }
    public List viewMember(){
        List<MemberDto> memberDtoList = memberRepository.findAll().stream().map(x-> MemberDto.fromMemeberEntity(x)).toList();
        return memberDtoList;
    }
    public List viewClass(){
        List<ClassDto> classDtoList = classRepository.findAll().stream().map(x-> ClassDto.fromClassEntity(x)).toList();
        return classDtoList;
    }
}
