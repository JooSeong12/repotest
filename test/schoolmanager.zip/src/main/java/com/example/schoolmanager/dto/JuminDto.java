package com.example.schoolmanager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class JuminDto {
    private String jumin;
    private String name;
    private String phone;
    private String address;
}
