package com.example.schoolmanager.mapper;

import com.example.schoolmanager.dto.TotalDto;
import com.example.schoolmanager.dto.VaccresvDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ReservationMapper {
    Long findResvNo();

    void saveReservation(@Param("vaccresvDto") VaccresvDto vaccresvDto);

    List<TotalDto> findTotal(@Param("resvNo") Long resvNo);
}
