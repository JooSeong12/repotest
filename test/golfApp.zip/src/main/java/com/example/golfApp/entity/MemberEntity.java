package com.example.golfApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="member")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberEntity {
    @Id
    private String member_id;
    private String member_name;
    private String phone;
    private String address;
    private String grade;
}
