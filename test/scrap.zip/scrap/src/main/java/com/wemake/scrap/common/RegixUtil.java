package com.wemake.scrap.common;

/**
 * 정규식 상수 클래스
 */
public class RegixUtil {

    public static final String ALPHABET = "[^a-zA-Z]";
    public static final String NUMBER = "[^0-9]";
    public static final String EMPTY = "";

}
